<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
        <h2 class="text-2xl font-bold mb-6 text-center text-gray-900">Tus Ventas</h2>

        <?php if(session('success')): ?>
            <div class="mb-4 text-green-700 font-semibold text-center">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="mb-6 text-right">
            <button onclick="openCreateModal()"
                class="inline-block px-4 py-2 text-sm font-semibold rounded border border-black text-black bg-white hover:bg-gray-100 transition">
                Registrar nueva venta
            </button>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full table-auto rounded border border-gray-200 shadow-sm bg-white text-sm">
                <thead class="bg-gray-100 text-gray-700 uppercase text-xs">
                    <tr>
                        <th class="px-4 py-3 text-left border-b">#</th>
                        <th class="px-4 py-3 text-left border-b">Productos</th>
                        <th class="px-4 py-3 text-left border-b">Total</th>
                        <th class="px-4 py-3 text-left border-b">Fecha</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-4 py-3 border-b"><?php echo e($loop->iteration); ?></td>
                            <td class="px-4 py-3 border-b">
                                <ul class="list-disc list-inside space-y-1">
                                    <?php $__currentLoopData = $sale->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <strong><?php echo e($product->name); ?></strong>
                                            <span>x <?php echo e($product->pivot->quantity); ?></span>
                                            <span class="text-gray-500">($<?php echo e(number_format($product->pivot->unit_price, 2)); ?> c/u)</span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                            <td class="px-4 py-3 border-b font-medium">
                                $<?php echo e(number_format($sale->total_price, 2)); ?>

                            </td>
                            <td class="px-4 py-3 border-b">
                                <?php echo e($sale->created_at->format('d/m/Y H:i')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center px-4 py-6 text-gray-500">
                                No hay ventas registradas.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>
    </div>

    <?php echo $__env->make('sales.create', ['products' => $products], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script>
        function openCreateModal() {
            document.getElementById('createModal').classList.remove('hidden');
        }

        function closeCreateModal() {
            document.getElementById('createModal').classList.add('hidden');
        }

        <?php if($errors->any()): ?>
            document.addEventListener('DOMContentLoaded', () => openCreateModal());
        <?php endif; ?>
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/sales/index.blade.php ENDPATH**/ ?>