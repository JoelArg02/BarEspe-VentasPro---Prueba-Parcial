<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-7xl mx-auto py-10 px-4">
    <h2 class="text-2xl font-bold mb-6 text-center text-gray-900">Listado de Usuarios</h2>

    <?php if(session('success')): ?>
        <div class="mb-4 p-4 text-green-800 bg-green-200 rounded text-center">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="overflow-x-auto">
        <table class="w-full table-auto rounded border border-gray-200 shadow-sm bg-white text-sm">
            <thead class="bg-gray-100 text-gray-700 uppercase text-xs">
                <tr>
                    <th class="px-4 py-3 text-left border-b">#</th>
                    <th class="px-4 py-3 text-left border-b">Nombre</th>
                    <th class="px-4 py-3 text-left border-b">Correo</th>
                    <th class="px-4 py-3 text-left border-b">Rol</th>
                    <?php if(auth()->user()->hasRole('admin')): ?>
                        <th class="px-4 py-3 text-left border-b">Acciones</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-4 py-3 border-b"><?php echo e($loop->iteration); ?></td>
                        <td class="px-4 py-3 border-b"><?php echo e($user->name); ?></td>
                        <td class="px-4 py-3 border-b"><?php echo e($user->email); ?></td>
                        <td class="px-4 py-3 border-b">
                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                                    <?php echo e($role->name); ?>

                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <?php if(auth()->user()->hasRole('admin')): ?>
                            <td class="px-4 py-3 border-b">
                                <button class="text-blue-600 hover:underline font-medium"
                                    onclick='openEditModal(<?php echo e($user->id); ?>, <?php echo json_encode($user->name, 15, 512) ?>, <?php echo json_encode($user->email, 15, 512) ?>, <?php echo json_encode($user->roles->pluck('name'), 15, 512) ?> )'>
                                    Editar
                                </button>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="<?php echo e(auth()->user()->hasRole('admin') ? 5 : 4); ?>"
                            class="text-center px-4 py-6 text-gray-500">
                            No hay usuarios registrados.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        <?php echo e($users->links()); ?>

    </div>
</div>



    <?php if(auth()->user()->hasRole('admin')): ?>
        <!-- Modal de Edición -->
        <div id="editModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50 flex items-center justify-center">
            <div class="bg-white rounded-lg p-6 w-full max-w-lg shadow-xl border border-gray-200">
                <h3 class="text-lg font-bold mb-4 text-gray-900">Editar Usuario</h3>
                <form id="editForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <input type="hidden" name="user_id" id="editUserId">

                    <div class="mb-4">
                        <label for="editName" class="block text-sm font-medium text-gray-700">Nombre</label>
                        <input type="text" name="name" id="editName"
                            class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                    </div>

                    <div class="mb-4">
                        <label for="editEmail" class="block text-sm font-medium text-gray-700">Correo</label>
                        <input type="email" name="email" id="editEmail"
                            class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                    </div>

                    <div class="mb-4">
                        <label for="editRole" class="block text-sm font-medium text-gray-700">Rol</label>
                        <select name="roles[]" id="editRole"
                            class="w-full px-4 py-2 rounded border border-gray-300">
                            <?php $__currentLoopData = \Spatie\Permission\Models\Role::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->name); ?>"><?php echo e(ucfirst($role->name)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="flex justify-end space-x-2">
                        <button type="button" onclick="closeEditModal()"
                            class="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded">
                            Cancelar
                        </button>

                        <button type="submit"
                            class="px-4 py-2 bg-white border border-black text-black hover:bg-gray-100 rounded">
                            Guardar
                        </button>
                    </div>
                </form>
            </div>
        </div>

    <?php endif; ?>

    <script>
        function openEditModal(id, name, email, roles) {
            const form = document.getElementById('editForm');
            document.getElementById('editUserId').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('editEmail').value = email;
            form.action = `/user/${id}`;

            // seleccionar solo el primer rol
            if (roles.length > 0) {
                document.getElementById('editRole').value = roles[0];
            }

            document.getElementById('editModal').classList.remove('hidden');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.add('hidden');
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/users/index.blade.php ENDPATH**/ ?>